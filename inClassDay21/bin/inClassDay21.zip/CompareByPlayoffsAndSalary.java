import java.util.Comparator;

public class CompareByPlayoffsAndSalary implements Comparator<BasketBallTeam> {
	
	public int compare(BasketBallTeam a, BasketBallTeam b){
		if(a.isPlayoffTeam() && !b.isPlayoffTeam()) {
			return -1;
		}
		else if(!a.isPlayoffTeam() && b.isPlayoffTeam()){
			return 1;
			}
		else {
			return (int) (a.getSalaryInMillions()-b.getSalaryInMillions());
			}
		}
	}

